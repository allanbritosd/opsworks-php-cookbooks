# this recipe will be deprecated in future releases
selinux_install 'selinux os prep'
